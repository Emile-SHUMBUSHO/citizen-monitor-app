export const slides = [
  {
    key: 1,
    title: "Enjoy your favourite movie everywhere",
    description:
      "Browser through our collectios and discover hundreds of movies and series that you'll love",
    image: require("../../assets/slides/1.jpeg"),
    backgroundColor: "#59b2ab",
  },
  {
    key: 2,
    title: "Title 2",
    description: "",
    image: require("../../assets/slides/4.png"),
    backgroundColor: "#febe29",
  },
  {
    key: 3,
    title: "Rocket guy",
    description: "I'm already out of descriptions\n\nLorem ipsum bla bla bla",
    image: require("../../assets/slides/3.jpeg"),
    backgroundColor: "#22bcb5",
  },
];
