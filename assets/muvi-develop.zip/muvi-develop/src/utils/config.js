// Import the functions you need from the SDKs you need
import * as  firebase from "firebase";
// TODO: Add SDKs for Firebase products that you want to use

const firebaseConfig = {
  apiKey: "AIzaSyCwh0uAiDzhVcUiR-eU9uYVDyvrXca5nH4",
  authDomain: "muvi-62bbf.firebaseapp.com",
  projectId: "muvi-62bbf",
  storageBucket: "muvi-62bbf.appspot.com",
  messagingSenderId: "858081043157",
  appId: "1:858081043157:web:5eaeb38c656e174088785c",
};
firebase.initializeApp(firebaseConfig);
export default firebase;
