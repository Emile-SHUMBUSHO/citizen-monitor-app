import { View, Text } from "react-native";
function Bookmark(props) {
  return (
    <>
      <View>
        <Text>My List</Text>
      </View>
    </>
  );
}

export default Bookmark;
