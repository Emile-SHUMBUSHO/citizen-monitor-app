import { View, Text } from "react-native";
function Origin(props) {
  return (
    <>
      <View>
        <Text>My List</Text>
      </View>
    </>
  );
}

export default Origin;
