import { Text, View } from "react-native";
function RateUsSetting() {
  return (
    <View>
      <Text>Rate us Settings</Text>
    </View>
  );
}
export default RateUsSetting;
