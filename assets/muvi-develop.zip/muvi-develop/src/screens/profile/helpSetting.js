import { Text, View } from "react-native";
function HelpSetting() {
  return (
    <View>
      <Text>help Settings</Text>
    </View>
  );
}
export default HelpSetting;
