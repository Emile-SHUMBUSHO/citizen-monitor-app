import { Text, View } from "react-native";
function AppSetting() {
  return (
    <View>
      <Text>app Settings</Text>
    </View>
  );
}
export default AppSetting;
