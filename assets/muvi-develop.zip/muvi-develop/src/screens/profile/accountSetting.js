import { Text, View } from "react-native";
function AccountSetting() {
  return (
    <View>
      <Text>Account Settings</Text>
    </View>
  );
}
export default AccountSetting;
