export default (type, payload) => ({
  type: type,
  payload: payload,
});
